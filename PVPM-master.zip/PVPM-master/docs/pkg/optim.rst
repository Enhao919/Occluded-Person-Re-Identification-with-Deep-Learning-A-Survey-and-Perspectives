.. _torchreid_optim:

torchreid.optim
=================


Optimizer
----------

.. automodule:: torchreid.optim.optimizer
    :members: build_optimizer


LR Scheduler
-------------

.. automodule:: torchreid.optim.lr_scheduler
    :members: build_lr_scheduler