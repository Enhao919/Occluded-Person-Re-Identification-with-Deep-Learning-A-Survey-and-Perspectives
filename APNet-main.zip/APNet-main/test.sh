CUDA_VISIBLE_DEVICES=0,1 python3 tools/test.py --config_file='configs/default.yml' TEST.WEIGHT 'WEIGHT_PATH'
