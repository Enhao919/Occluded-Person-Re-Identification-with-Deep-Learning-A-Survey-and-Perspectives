CUDA_VISIBLE_DEVICES=0,1 python3 tools/train.py --config_file='configs/msmt.yml' 
